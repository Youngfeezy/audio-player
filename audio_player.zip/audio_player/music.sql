-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 10, 2021 at 06:08 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `feezymusic2`
--

-- --------------------------------------------------------

--
-- Table structure for table `top`
--

CREATE TABLE `top` (
  `song_id` int(11) NOT NULL,
  `song_name` varchar(50) NOT NULL,
  `artist_name` varchar(50) NOT NULL,
  `song_year` varchar(30) NOT NULL,
  `description` varchar(200) NOT NULL,
  `song_genre` varchar(30) NOT NULL,
  `song_image` varchar(50) NOT NULL,
  `song_audio` varchar(50) NOT NULL,
  `album` varchar(50) NOT NULL,
  `artist_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `top`
--

INSERT INTO `top` (`song_id`, `song_name`, `artist_name`, `song_year`, `description`, `song_genre`, `song_image`, `song_audio`, `album`, `artist_id`) VALUES
(1, 'black is king', 'Beyonce', '2020', 'Great Song', 'Hip Hop', 'black is king.jfif', 'Beyonce_Ft_Wizkid_And_Blue_Ivy_Brown_Skin_Girls.mp', 'None', '1'),
(2, 'Joker', 'Dax', '2020', 'I am not a joker', 'Rap', 'cole.jpg', 'Dax – Joker.mp3', 'None', '2');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

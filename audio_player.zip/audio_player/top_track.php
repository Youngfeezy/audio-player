



<!DOCTYPE html>

<html lang="en">


<head>

    <link rel="stylesheet" type="text/css" href="css/fonts.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="js/plugins/swiper/css/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="js/plugins/nice_select/nice-select.css">
    <link rel="stylesheet" type="text/css" href="js/plugins/player/volume.css">
  <link rel="stylesheet" type="text/css" href="js/plugins/scroll/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

</head>




<body>

           <!----Main Wrapper Start-->
    <div class="ms_main_wrapper ms_profile">

        <!---Side Menu Start-->
     
        <!---Main Content Start-->
        <div class="ms_content_wrapper padder_top90">
            <!---Header-->
            <br>
                 
     <!---Weekly Top 15-->
            <div class="ms_weekly_wrapper">
                <div class="ms_weekly_inner">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="ms_heading">
                                <h1>How can i play & pause the audio files on click of the image play icon</h1>

                            </div>
                        </div>
                        <div class="col-lg-4 col-md-12 padding_right40">
                                   
                                 <?php
                    require '../db.php';
                    $sql = "select * from top Limit 10";
                   $sql_query = mysqli_query($con,$sql);
                        $i=1;
                     while ($row = mysqli_fetch_array($sql_query)) {
                            $image = $row['song_image'];
                            $song_name = $row['song_name'];
                            $artist_name = $row['artist_name'];
                            $song_audio = $row['song_audio'];
                              ?>


                            <div class="ms_weekly_box">
                                <div class="weekly_left">
                                    <span class="w_top_no">
                    <?php if(isset($i)){ echo $i;}?>
                  </span>
                                    <div class="w_top_song">
                                        <div class="w_tp_song_img">
                                            <img src="songImages/<?php if(isset($image)){ echo $image;}?>" alt="">
                                            <div class="ms_song_overlay">
                                            </div>
                                            <div class="ms_play_icon">
                                                <img src="images/svg/play.svg" alt="">
                                            </div>
                                        </div>
                                        <div class="w_tp_song_name">
                                            <h3><a href="#"><?php if(isset($song_name)){ echo $song_name;}?></a></h3>
                                            <p><?php if(isset($artist_name)){ echo $artist_name;}?></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="weekly_right">
                                   <p style="color: white">How can i display the audio duration here</p>
                                    <span class="w_song_time">5:10</span>
                                             
                                </span>
                                </div>
                            
                            </div>
                            <div class="ms_divider"></div>

                            <?php
                               $i++;
                                }
                            ?>
                            
              
                        </div>
                    </div>
                </div>
            </div>

            
            <!----Main div close---->
        </div>
        </div>




       <!----Footer Start---->
          





                    <!----Audio Player Section---->
        <div class="ms_player_wrapper">
            <div class="ms_player_close">
                <i class="fa fa-angle-up" aria-hidden="true"></i>
            </div>
            <div class="player_mid">
                <div class="audio-player">
                    <div id="jquery_jplayer_1" class="jp-jplayer"></div>
                    <div id="jp_container_1" class="jp-audio" role="application" aria-label="media player">
                        <div class="player_left">
                            <div class="ms_play_song">
                                <div class="play_song_name">
                                    <a href="javascript:void(0);" id="playlist-text">
                                        <div class="jp-now-playing flex-item">
                                            <div class="jp-track-name"></div>
                                            <div class="jp-artist-name"></div>
                                        </div>
                                    </a>
                                </div>
                            </div>
                         
                            <span class="play-left-arrow"><i class="fa fa-angle-right" aria-hidden="true"></i></span>
                        </div>
                        <!----Right Queue---->
                        <div class="jp_queue_wrapper">
                            <span class="que_text" id="myPlaylistQueue"><i class="fa fa-angle-up" aria-hidden="true"></i> queue</span>
                            <div id="playlist-wrap" class="jp-playlist">
                                <div class="jp_queue_cls"><i class="fa fa-times" aria-hidden="true"></i></div>
                                <h2>queue</h2>
                                <div class="jp_queue_list_inner">
                                    <ul>
                                        <li>&nbsp;</li>
                                    </ul>
                                </div>
                                <div class="jp_queue_btn">
                                    <a href="javascript:;" class="ms_clear" data-toggle="modal" data-target="#clear_modal">clear</a>
                                    <a href="clear_modal" class="ms_save" data-toggle="modal" data-target="#save_modal">save</a>
                                </div>
                            </div>
                        </div>
                        <div class="jp-type-playlist">
                            <div class="jp-gui jp-interface flex-wrap">
                                <div class="jp-controls flex-item">
                                    <button class="jp-previous" tabindex="0">
                    <i class="ms_play_control"></i>
                </button>
                                    <button class="jp-play" tabindex="0">
                    <i class="ms_play_control"></i>
                </button>
                                    <button class="jp-next" tabindex="0">
                    <i class="ms_play_control"></i>
                </button>
                                </div>
                                <div class="jp-progress-container flex-item">
                                    <div class="jp-time-holder">
                                        <span class="jp-current-time" role="timer" aria-label="time">&nbsp;</span>
                                        <span class="jp-duration" role="timer" aria-label="duration">&nbsp;</span>
                                    </div>
                                    <div class="jp-progress">
                                        <div class="jp-seek-bar">
                                            <div class="jp-play-bar">
                                                <div class="bullet">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="jp-volume-controls flex-item">
                                    <div class="widget knob-container">
                                        <div class="knob-wrapper-outer">
                                            <div class="knob-wrapper">
                                                <div class="knob-mask">
                                                    <div class="knob d3"><span></span></div>
                                                    <div class="handle"></div>
                                                    <div class="round">
                                                        <img src="images/svg/volume.svg" alt="">
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- <input></input> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="jp-toggles flex-item">
                                    <button class="jp-shuffle" tabindex="0" title="Shuffle">
                                    <i class="ms_play_control"></i></button>
                                    <button class="jp-repeat" tabindex="0" title="Repeat"><i class="ms_play_control"></i></button>
                                </div>
                                <div class="jp_quality_optn custom_select">
                                    <select>
                        <option>quality</option>
                        <option value="1">HD</option>
                        <option value="2">High</option>
                        <option value="3">medium</option>
                        <option value="4">low</option>
                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--main div-->
        </div>


            
            <!----Copyright---->
            <div class="col-lg-12" style="background-color: #14182a;">
                <div class="ms_copyright">
                    <div class="footer_border"></div>
                    <p>And also, How can i play the music with the audio player below. Thank you so much for trying to help me. I really appreciate.</p>
                </div>
            </div>
    </div>

  
    <!--Main js file Style-->
        <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/plugins/swiper/js/swiper.min.js"></script>
    <script type="text/javascript" src="js/plugins/player/jplayer.playlist.min.js"></script>
    <script type="text/javascript" src="js/plugins/player/jquery.jplayer.min.js"></script>
    <script type="text/javascript" src="js/plugins/player/audio-player.js"></script>
    <script type="text/javascript" src="js/plugins/player/volume.js"></script>
    <script type="text/javascript" src="js/plugins/nice_select/jquery.nice-select.min.js"></script>
    <script type="text/javascript" src="js/plugins/scroll/jquery.mCustomScrollbar.js"></script>
    <script type="text/javascript" src="js/custom.js"></script>

</body>






</html>



